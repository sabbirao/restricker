package com.restricker.app

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    var isSelected: Boolean
)

class MainActivity : AppCompatActivity() {

    private lateinit var tvUnlockTimeHero: TextView
    private lateinit var layoutAutoRelockRow: View
    private lateinit var tvAutoRelockSubtitle: TextView
    private lateinit var switchAutoRelock: MaterialSwitch
    private lateinit var cardTimerMode: View
    private lateinit var cardTextChallengeMode: View
    private lateinit var npHours: NumberPicker
    private lateinit var npMinutes: NumberPicker
    private lateinit var btnStartLock: Button

    private lateinit var tvChallengeHeader: TextView
    private lateinit var btnStartTextLock: Button
    private lateinit var layoutActiveChallenge: View
    private lateinit var tvChallengeProgress: TextView
    private lateinit var tvChallengeTarget: TextView
    private lateinit var etChallengeInput: NoPasteEditText
    private lateinit var btnSubmitChallenge: Button

    private lateinit var rvApps: RecyclerView

    private val appList = mutableListOf<AppEntry>()
    private lateinit var adapter: AppListAdapter
    private lateinit var layoutManager: LinearLayoutManager
    private val uiHandler = Handler(Looper.getMainLooper())
    private var isRejectingPaste = false
    private var lastValidTypedText = ""

    private val uiTicker = object : Runnable {
        override fun run() {
            refreshLockStateUI()
            uiHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        LockStateManager.applyTheme(LockStateManager.getThemeMode(this))
        super.onCreate(savedInstanceState)
        // Block screenshots & screen recordings so user cannot OCR/screenshot the random challenge text
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        setContentView(R.layout.activity_main)

        LockStateManager.syncBangladeshInternationalTime(this)

        val rootScroll = findViewById<androidx.core.widget.NestedScrollView>(R.id.rootScrollMain)
        val sidePad = dpToPx(26)
        val extraTop = dpToPx(24)
        val extraBottom = dpToPx(28)
        ViewCompat.setOnApplyWindowInsetsListener(rootScroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(
                left = sidePad + bars.left,
                top = bars.top + extraTop,
                right = sidePad + bars.right,
                bottom = bars.bottom + extraBottom
            )
            insets
        }

        tvUnlockTimeHero = findViewById(R.id.tvUnlockTimeHero)
        layoutAutoRelockRow = findViewById(R.id.layoutAutoRelockRow)
        tvAutoRelockSubtitle = findViewById(R.id.tvAutoRelockSubtitle)
        switchAutoRelock = findViewById(R.id.switchAutoRelock)
        cardTimerMode = findViewById(R.id.cardTimerMode)
        cardTextChallengeMode = findViewById(R.id.cardTextChallengeMode)
        npHours = findViewById(R.id.npHours)
        npMinutes = findViewById(R.id.npMinutes)
        btnStartLock = findViewById(R.id.btnStartLock)

        tvChallengeHeader = findViewById(R.id.tvChallengeHeader)
        btnStartTextLock = findViewById(R.id.btnStartTextLock)
        layoutActiveChallenge = findViewById(R.id.layoutActiveChallenge)
        tvChallengeProgress = findViewById(R.id.tvChallengeProgress)
        tvChallengeTarget = findViewById(R.id.tvChallengeTarget)
        etChallengeInput = findViewById(R.id.etChallengeInput)
        btnSubmitChallenge = findViewById(R.id.btnSubmitChallenge)
        rvApps = findViewById(R.id.rvApps)

        findViewById<ImageButton>(R.id.btnOpenSettings).setOnClickListener {
            if (LockStateManager.isLockActive(this)) {
                Toast.makeText(this, "Locked", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        npHours.minValue = 0
        npHours.maxValue = 23
        npHours.value = LockStateManager.getSavedHours(this)

        npMinutes.minValue = 0
        npMinutes.maxValue = 59
        npMinutes.value = LockStateManager.getSavedMinutes(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val bigPx = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP,
                28f,
                resources.displayMetrics
            )
            npHours.textSize = bigPx
            npMinutes.textSize = bigPx
        }

        val pickerListener = NumberPicker.OnValueChangeListener { _, _, _ ->
            LockStateManager.setSavedHoursAndMinutes(this, npHours.value, npMinutes.value)
            if (!LockStateManager.isLockActive(this)) {
                updatePreviewUnlockTime()
            }
        }
        npHours.setOnValueChangedListener(pickerListener)
        npMinutes.setOnValueChangedListener(pickerListener)

        switchAutoRelock.isChecked = LockStateManager.isAutoRelockEnabled(this)
        switchAutoRelock.setOnCheckedChangeListener { _, isChecked ->
            if (LockStateManager.isLockActive(this) && !isChecked) {
                switchAutoRelock.isChecked = true
                return@setOnCheckedChangeListener
            }
            LockStateManager.setAutoRelockEnabled(this, isChecked)
            refreshLockStateUI()
        }

        btnStartLock.setOnClickListener {
            if (LockStateManager.isLockActive(this)) return@setOnClickListener
            if (!checkPermissionsBeforeLock()) return@setOnClickListener

            val selectedPkgs = appList.filter { it.isSelected }.map { it.packageName }.toSet()
            if (selectedPkgs.isEmpty()) {
                Toast.makeText(this, "Select Apps first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val durationMs = (npHours.value * 3600L + npMinutes.value * 60L) * 1000L
            if (durationMs < 60_000L) {
                Toast.makeText(this, "Select Lock Duration", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            LockStateManager.setSavedHoursAndMinutes(this, npHours.value, npMinutes.value)
            LockStateManager.setLockedPackages(this, selectedPkgs)
            LockStateManager.startTimerLockSession(this, durationMs, switchAutoRelock.isChecked)
            refreshLockStateUI()
        }

        btnStartTextLock.setOnClickListener {
            if (LockStateManager.isLockActive(this)) return@setOnClickListener
            if (!checkPermissionsBeforeLock()) return@setOnClickListener

            val selectedPkgs = appList.filter { it.isSelected }.map { it.packageName }.toSet()
            if (selectedPkgs.isEmpty()) {
                Toast.makeText(this, "Select Apps first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            LockStateManager.setLockedPackages(this, selectedPkgs)
            LockStateManager.startTextChallengeLockSession(this)
            lastValidTypedText = ""
            etChallengeInput.setText("")
            refreshLockStateUI()
        }

        // Anti-paste TextWatcher: blocks multi-character paste from keyboard clipboard bar!
        etChallengeInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (isRejectingPaste) return
                val current = s?.toString() ?: ""
                if (count > 1 && current.length - lastValidTypedText.length > 1) {
                    isRejectingPaste = true
                    etChallengeInput.setText(lastValidTypedText)
                    etChallengeInput.setSelection(lastValidTypedText.length)
                    isRejectingPaste = false
                    Toast.makeText(this@MainActivity, "Manual typing only", Toast.LENGTH_SHORT).show()
                    return
                }
                lastValidTypedText = current
                updateChallengeProgressText(current)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        btnSubmitChallenge.setOnClickListener {
            val target = LockStateManager.getActiveChallengeText(this)
            val typed = etChallengeInput.text?.toString() ?: ""
            if (target.isNotEmpty() && typed == target) {
                LockStateManager.unlockTextChallenge(this)
                lastValidTypedText = ""
                etChallengeInput.setText("")
                Toast.makeText(this, "Unlocked", Toast.LENGTH_SHORT).show()
                refreshLockStateUI()
            } else {
                val mismatchIdx = findFirstMismatchIndex(typed, target)
                Toast.makeText(
                    this,
                    "Mismatch at character ${mismatchIdx + 1}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        setupAppRecyclerView()
    }

    private fun findFirstMismatchIndex(typed: String, target: String): Int {
        val minLen = minOf(typed.length, target.length)
        for (i in 0 until minLen) {
            if (typed[i] != target[i]) return i
        }
        return minLen
    }

    private fun updateChallengeProgressText(typed: String) {
        val target = LockStateManager.getActiveChallengeText(this)
        if (target.isEmpty()) return
        val matched = findFirstMismatchIndex(typed, target)
        val hasError = typed.length > matched
        tvChallengeProgress.text = if (hasError) {
            "$matched / ${target.length} (Error at #${matched + 1})"
        } else {
            "$matched / ${target.length}"
        }
    }

    private fun checkPermissionsBeforeLock(): Boolean {
        if (!Settings.canDrawOverlays(this) || !isAccessibilityEnabled()) {
            Toast.makeText(this, "Enable Overlay & App Guard in Settings first", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return false
        }
        return true
    }

    override fun onResume() {
        super.onResume()
        LockStateManager.syncBangladeshInternationalTime(this)
        tvAutoRelockSubtitle.text = "After ${LockStateManager.getGraceMinutes(this)} minutes"
        refreshLockStateUI()
        uiHandler.post(uiTicker)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(uiTicker)
        super.onPause()
    }

    private fun updatePreviewUnlockTime() {
        val durationMs = (npHours.value * 3600L + npMinutes.value * 60L) * 1000L
        val previewUnlockAt = LockStateManager.nowInternationalMs(this) + durationMs
        tvUnlockTimeHero.text = "Unlocks at ${LockStateManager.formatClockTime(previewUnlockAt)}"
    }

    private fun refreshLockStateUI() {
        val isLocked = LockStateManager.isLockActive(this)
        val effectiveMode = if (isLocked) {
            LockStateManager.getActiveLockMode(this)
        } else {
            LockStateManager.getConfiguredLockMode(this)
        }

        tvAutoRelockSubtitle.text = "After ${LockStateManager.getGraceMinutes(this)} minutes"

        if (effectiveMode == LockStateManager.MODE_TEXT_CHALLENGE) {
            layoutAutoRelockRow.visibility = View.GONE
            cardTimerMode.visibility = View.GONE
            cardTextChallengeMode.visibility = View.VISIBLE

            val targetLen = if (isLocked) {
                LockStateManager.getActiveChallengeText(this).length
            } else {
                LockStateManager.getChallengeLength(this)
            }
            tvChallengeHeader.text = "Type $targetLen Characters"

            if (isLocked) {
                tvUnlockTimeHero.text = "Locked ($targetLen chars)"
                btnStartTextLock.visibility = View.GONE
                layoutActiveChallenge.visibility = View.VISIBLE
                val targetText = LockStateManager.getActiveChallengeText(this)
                if (tvChallengeTarget.text.toString() != targetText) {
                    tvChallengeTarget.text = targetText
                }
                updateChallengeProgressText(etChallengeInput.text?.toString() ?: "")
            } else {
                tvUnlockTimeHero.text = "Random Text Lock"
                btnStartTextLock.visibility = View.VISIBLE
                layoutActiveChallenge.visibility = View.GONE
            }
        } else {
            layoutAutoRelockRow.visibility = View.VISIBLE
            cardTimerMode.visibility = View.VISIBLE
            cardTextChallengeMode.visibility = View.GONE

            npHours.isEnabled = !isLocked
            npMinutes.isEnabled = !isLocked
            btnStartLock.isEnabled = !isLocked

            if (isLocked) {
                val unlockAt = LockStateManager.getUnlockTimeMs(this)
                tvUnlockTimeHero.text = "Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
            } else {
                updatePreviewUnlockTime()
            }
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(packageName)
    }

    private fun sortAppsSelectedToTop() {
        appList.sortWith(compareByDescending<AppEntry> { it.isSelected }.thenBy { it.label.lowercase() })
    }

    private fun setupAppRecyclerView() {
        val pm = packageManager
        val savedSelection = LockStateManager.getLockedPackages(this)
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        appList.clear()
        for (appInfo in installed) {
            val pkg = appInfo.packageName
            if (pkg == packageName || LockStateManager.PROTECTED_INSTALLER_PACKAGES.contains(pkg)) continue
            val isSettingsApp = (pkg == "com.android.settings")
            if (!isSettingsApp && pm.getLaunchIntentForPackage(pkg) == null) continue

            val label = if (isSettingsApp) "Settings" else pm.getApplicationLabel(appInfo).toString()
            val icon = pm.getApplicationIcon(appInfo)
            val selected = savedSelection.contains(pkg)
            appList.add(AppEntry(label, pkg, icon, selected))
        }

        sortAppsSelectedToTop()

        layoutManager = LinearLayoutManager(this)
        rvApps.layoutManager = layoutManager
        rvApps.itemAnimator = DefaultItemAnimator().apply {
            moveDuration = 460L
            changeDuration = 250L
        }

        adapter = AppListAdapter(appList) { clickedItem, desiredSelected, rowView ->
            // During an active lock: user CAN ADD new apps to the lock, but CANNOT REMOVE already-locked apps!
            if (LockStateManager.isLockActive(this) && !desiredSelected) {
                Toast.makeText(this, "Cannot remove apps while locked", Toast.LENGTH_SHORT).show()
                return@AppListAdapter false
            }

            clickedItem.isSelected = desiredSelected

            val fromPos = appList.indexOfFirst { it.packageName == clickedItem.packageName }
            if (fromPos == -1) return@AppListAdapter false

            val firstVis = layoutManager.findFirstVisibleItemPosition()
            val lastVis = layoutManager.findLastVisibleItemPosition()
            var anchorPkg: String? = null
            var anchorTop = 0
            if (firstVis != RecyclerView.NO_POSITION) {
                for (pos in firstVis..lastVis) {
                    val candidate = appList.getOrNull(pos) ?: continue
                    if (candidate.packageName != clickedItem.packageName) {
                        val v = layoutManager.findViewByPosition(pos)
                        if (v != null) {
                            anchorPkg = candidate.packageName
                            anchorTop = v.top
                            break
                        }
                    }
                }
            }

            val selectedSet = appList.filter { it.isSelected }.map { it.packageName }.toSet()
            LockStateManager.setLockedPackages(this, selectedSet)

            sortAppsSelectedToTop()
            val toPos = appList.indexOfFirst { it.packageName == clickedItem.packageName }

            if (toPos != -1 && fromPos != toPos) {
                adapter.notifyItemMoved(fromPos, toPos)
                if (anchorPkg != null) {
                    val newAnchorPos = appList.indexOfFirst { it.packageName == anchorPkg }
                    if (newAnchorPos != -1) {
                        layoutManager.scrollToPositionWithOffset(newAnchorPos, anchorTop)
                    }
                }
            }

            rowView.animate()
                .scaleX(0.96f)
                .scaleY(0.96f)
                .setDuration(110L)
                .withEndAction {
                    rowView.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setInterpolator(OvershootInterpolator(1.6f))
                        .setDuration(260L)
                        .start()
                }
                .start()

            true
        }
        rvApps.adapter = adapter
    }

    private fun dpToPx(dp: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()

    inner class AppListAdapter(
        private val items: List<AppEntry>,
        private val onToggleRequested: (AppEntry, Boolean, View) -> Boolean
    ) : RecyclerView.Adapter<AppListAdapter.VH>() {

        init {
            setHasStableIds(true)
        }

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val ivIcon: ImageView = view.findViewById(R.id.ivAppIcon)
            val tvName: TextView = view.findViewById(R.id.tvAppName)
            val ivCheck: ImageView = view.findViewById(R.id.ivAppCheck)
        }

        override fun getItemId(position: Int): Long =
            items[position].packageName.hashCode().toLong()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app_select, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.ivIcon.setImageDrawable(item.icon)
            holder.tvName.text = item.label
            holder.ivCheck.setImageResource(
                if (item.isSelected) R.drawable.ic_check_circle_red else R.drawable.ic_check_circle_off
            )

            holder.itemView.setOnClickListener {
                val desired = !item.isSelected
                if (onToggleRequested(item, desired, holder.itemView)) {
                    holder.ivCheck.setImageResource(
                        if (item.isSelected) R.drawable.ic_check_circle_red else R.drawable.ic_check_circle_off
                    )
                }
            }
        }

        override fun getItemCount(): Int = items.size
    }
}
