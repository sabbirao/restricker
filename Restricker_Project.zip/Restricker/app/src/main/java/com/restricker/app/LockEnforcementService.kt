package com.restricker.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class LockEnforcementService : Service() {

    companion object {
        private const val CHANNEL_ID = "restricker_lock_channel"
        private const val NOTIF_ID = 1630

        fun startOrUpdate(context: Context) {
            val intent = Intent(context, LockEnforcementService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null

    private val loopRunnable = object : Runnable {
        override fun run() {
            val inGrace = LockStateManager.isInGraceWindow(this@LockEnforcementService)

            if (inGrace) {
                if (LockStateManager.getRemainingGraceMs(this@LockEnforcementService) <= 0L) {
                    LockStateManager.onGraceWindowExpired(this@LockEnforcementService)
                }
            }

            if (!LockStateManager.isLockActive(this@LockEnforcementService) &&
                !LockStateManager.isInGraceWindow(this@LockEnforcementService)
            ) {
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }

            updateNotification()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildStatusNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        LockStateManager.scheduleWatchdogHeartbeat(this)
        handler.removeCallbacks(loopRunnable)
        handler.post(loopRunnable)
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockStateManager.scheduleExactAlarm(
                this,
                System.currentTimeMillis() + 250L,
                LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT
            )
            startOrUpdate(this)
        }
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Restricker::LockGuardWakeLock").apply {
                setReferenceCounted(false)
                acquire(24 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {
        }
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildStatusNotification())
    }

    private fun buildStatusNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title: String
        val body: String

        if (LockStateManager.isLockActive(this)) {
            if (LockStateManager.getActiveLockMode(this) == LockStateManager.MODE_TEXT_CHALLENGE) {
                val len = LockStateManager.getActiveChallengeText(this).length
                title = "Restricker Strict Lock Active"
                body = "Type $len random characters to unlock"
            } else {
                val unlockAt = LockStateManager.getUnlockTimeMs(this)
                val rem = LockStateManager.getRemainingLockMs(this)
                title = "Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
                body = "${LockStateManager.formatCountdownTimer(rem)} • ${LockStateManager.getCustomQuote(this)}"
            }
        } else {
            val graceEnd = LockStateManager.getGraceEndTimeMs(this)
            val remGrace = LockStateManager.getRemainingGraceMs(this)
            title = "Auto-relock at ${LockStateManager.formatClockTime(graceEnd)}"
            body = "${LockStateManager.formatCountdownTimer(remGrace)} left to toggle off Auto-relock"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Restricker Active Lock",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(loopRunnable)
        releaseWakeLock()
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockStateManager.scheduleExactAlarm(
                this,
                System.currentTimeMillis() + 250L,
                LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT
            )
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
