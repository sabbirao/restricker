package com.restricker.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

class SettingsActivity : AppCompatActivity() {

    private lateinit var rgLockType: RadioGroup
    private lateinit var etChallengeLength: EditText
    private lateinit var etGraceMinutes: EditText
    private lateinit var etCustomQuote: EditText
    private lateinit var rgTheme: RadioGroup
    private lateinit var ivCheckOverlay: ImageView
    private lateinit var ivCheckAdmin: ImageView
    private lateinit var ivCheckAccessibility: ImageView
    private lateinit var ivCheckBattery: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        LockStateManager.applyTheme(LockStateManager.getThemeMode(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val rootScroll = findViewById<androidx.core.widget.NestedScrollView>(R.id.rootScrollSettings)
        val sidePad = dpToPx(26)
        val extraTop = dpToPx(24)
        val extraBottom = dpToPx(28)
        ViewCompat.setOnApplyWindowInsetsListener(rootScroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(
                left = sidePad + bars.left,
                top = bars.top + extraTop,
                right = sidePad + bars.right,
                bottom = bars.bottom + extraBottom
            )
            insets
        }

        rgLockType = findViewById(R.id.rgLockType)
        etChallengeLength = findViewById(R.id.etChallengeLength)
        etGraceMinutes = findViewById(R.id.etGraceMinutes)
        etCustomQuote = findViewById(R.id.etCustomQuote)
        rgTheme = findViewById(R.id.rgTheme)
        ivCheckOverlay = findViewById(R.id.ivCheckOverlay)
        ivCheckAdmin = findViewById(R.id.ivCheckAdmin)
        ivCheckAccessibility = findViewById(R.id.ivCheckAccessibility)
        ivCheckBattery = findViewById(R.id.ivCheckBattery)

        findViewById<ImageButton>(R.id.btnBackSettings).setOnClickListener {
            finish()
        }

        when (LockStateManager.getConfiguredLockMode(this)) {
            LockStateManager.MODE_TEXT_CHALLENGE -> rgLockType.check(R.id.rbLockText)
            else -> rgLockType.check(R.id.rbLockTimer)
        }
        etChallengeLength.setText(LockStateManager.getChallengeLength(this).toString())
        etGraceMinutes.setText(LockStateManager.getGraceMinutes(this).toString())
        etCustomQuote.setText(LockStateManager.getCustomQuote(this))

        when (LockStateManager.getThemeMode(this)) {
            LockStateManager.THEME_DARK -> rgTheme.check(R.id.rbThemeDark)
            LockStateManager.THEME_LIGHT -> rgTheme.check(R.id.rbThemeLight)
            else -> rgTheme.check(R.id.rbThemeSystem)
        }

        rgTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.rbThemeDark -> LockStateManager.THEME_DARK
                R.id.rbThemeLight -> LockStateManager.THEME_LIGHT
                else -> LockStateManager.THEME_SYSTEM
            }
            LockStateManager.setThemeMode(this, mode)
        }

        findViewById<Button>(R.id.btnSaveSettings).setOnClickListener {
            val selectedLockMode = if (rgLockType.checkedRadioButtonId == R.id.rbLockText) {
                LockStateManager.MODE_TEXT_CHALLENGE
            } else {
                LockStateManager.MODE_TIMER
            }
            val charLen = etChallengeLength.text.toString().toIntOrNull() ?: 250
            val mins = etGraceMinutes.text.toString().toIntOrNull() ?: 30
            val quote = etCustomQuote.text.toString()

            LockStateManager.setConfiguredLockMode(this, selectedLockMode)
            LockStateManager.setChallengeLength(this, charLen)
            LockStateManager.setGraceMinutes(this, mins)
            LockStateManager.setCustomQuote(this, quote)
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<View>(R.id.btnEnableOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        findViewById<View>(R.id.btnEnableAdmin).setOnClickListener {
            val comp = ComponentName(this, BlockerDeviceAdminReceiver::class.java)
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
            }
            startActivity(intent)
        }

        findViewById<View>(R.id.btnEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<View>(R.id.btnIgnoreBattery).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionCheckmarks()
    }

    private fun refreshPermissionCheckmarks() {
        val overlayOk = Settings.canDrawOverlays(this)
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminOk = dpm.isAdminActive(ComponentName(this, BlockerDeviceAdminReceiver::class.java))
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val accessOk = enabledServices.contains(packageName)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pm.isIgnoringBatteryOptimizations(packageName)
        } else true

        ivCheckOverlay.setImageResource(
            if (overlayOk) R.drawable.ic_check_circle_green else R.drawable.ic_check_circle_off
        )
        ivCheckAdmin.setImageResource(
            if (adminOk) R.drawable.ic_check_circle_green else R.drawable.ic_check_circle_off
        )
        ivCheckAccessibility.setImageResource(
            if (accessOk) R.drawable.ic_check_circle_green else R.drawable.ic_check_circle_off
        )
        ivCheckBattery.setImageResource(
            if (batteryOk) R.drawable.ic_check_circle_green else R.drawable.ic_check_circle_off
        )
    }

    private fun dpToPx(dp: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
}
